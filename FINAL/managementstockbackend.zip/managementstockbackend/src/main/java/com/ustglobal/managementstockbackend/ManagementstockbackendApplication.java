package com.ustglobal.managementstockbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagementstockbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagementstockbackendApplication.class, args);
	}

}
